import { useAuth } from './contexts/AuthContext';
import { Auth } from './components/Auth';
import { MainApp } from './components/MainApp';

function App() {
  const { user, loading } = useAuth();

  if (loading) {
    return (
      <div className="min-h-screen bg-gray-100 flex items-center justify-center">
        <div className="text-gray-600">Loading...</div>
      </div>
    );
  }

  return user ? <MainApp /> : <Auth />;
}

export default App;
