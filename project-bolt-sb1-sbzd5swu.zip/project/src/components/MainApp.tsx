import React, { useState } from 'react';
import { BookOpen, Users, BookMarked, LayoutDashboard, LogOut, UserCog } from 'lucide-react';
import { useAuth } from '../contexts/AuthContext';
import { Dashboard } from './Dashboard';
import { BookManagement } from './BookManagement';
import { StudentManagement } from './StudentManagement';
import { StaffManagement } from './StaffManagement';
import { BorrowingSystem } from './BorrowingSystem';

type Tab = 'dashboard' | 'books' | 'students' | 'staff' | 'borrowing';

export function MainApp() {
  const [activeTab, setActiveTab] = useState<Tab>('dashboard');
  const { signOut } = useAuth();

  const handleSignOut = async () => {
    try {
      await signOut();
    } catch (error) {
      console.error('Error signing out:', error);
    }
  };

  const tabs = [
    { id: 'dashboard' as Tab, label: 'Dashboard', icon: LayoutDashboard },
    { id: 'books' as Tab, label: 'Books', icon: BookOpen },
    { id: 'students' as Tab, label: 'Students', icon: Users },
    { id: 'staff' as Tab, label: 'Staff', icon: UserCog },
    { id: 'borrowing' as Tab, label: 'Borrowing', icon: BookMarked },
  ];

  return (
    <div className="min-h-screen bg-gray-50">
      <header className="bg-white shadow-sm border-b border-gray-200">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-4">
          <div className="flex items-center justify-between">
            <div className="flex items-center">
              <BookOpen className="h-8 w-8 text-blue-600 mr-3" />
              <div>
                <h1 className="text-2xl font-bold text-gray-900">IISBenin Library Management System</h1>
              </div>
            </div>
            <button
              onClick={handleSignOut}
              className="flex items-center gap-2 px-4 py-2 text-gray-700 hover:text-gray-900 hover:bg-gray-100 rounded-lg transition-colors"
            >
              <LogOut className="h-5 w-5" />
              <span>Sign Out</span>
            </button>
          </div>
        </div>
      </header>

      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-6">
        <nav className="flex gap-2 mb-6 bg-white rounded-lg p-2 shadow-sm border border-gray-200">
          {tabs.map((tab) => {
            const Icon = tab.icon;
            return (
              <button
                key={tab.id}
                onClick={() => setActiveTab(tab.id)}
                className={`flex items-center gap-2 px-4 py-2 rounded-lg font-medium transition-colors ${
                  activeTab === tab.id
                    ? 'bg-blue-600 text-white'
                    : 'text-gray-700 hover:bg-gray-100'
                }`}
              >
                <Icon className="h-5 w-5" />
                <span>{tab.label}</span>
              </button>
            );
          })}
        </nav>

        <div className="bg-white rounded-xl shadow-sm border border-gray-200 p-6">
          {activeTab === 'dashboard' && <Dashboard />}
          {activeTab === 'books' && <BookManagement />}
          {activeTab === 'students' && <StudentManagement />}
          {activeTab === 'staff' && <StaffManagement />}
          {activeTab === 'borrowing' && <BorrowingSystem />}
        </div>
      </div>
    </div>
  );
}
